-- 随 2.0.0(Supabase 化)发布:PostgREST 角色授权
-- 原则:匿名(anon)只开放确实要公开的表;内部表一律不给;生产环境建议再叠加 RLS
GRANT USAGE ON SCHEMA public TO anon, authenticated, service_role;

-- 公告表:公开可读(演示 supabase-js 匿名读取)
GRANT SELECT ON announcements TO anon, authenticated, service_role;

-- 服务端角色可读全部(仅 service_role,持有 SERVICE_ROLE_KEY 的服务端代码用)
GRANT SELECT ON ALL TABLES IN SCHEMA public TO service_role;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO service_role;

-- 内部表明确收权:匿名/登录用户都不可见
REVOKE ALL ON schema_migrations FROM anon, authenticated;
REVOKE ALL ON app_info FROM anon, authenticated;

-- 通知 PostgREST 重载 schema 缓存
NOTIFY pgrst, 'reload schema';
