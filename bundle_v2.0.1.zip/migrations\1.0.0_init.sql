-- 初始迁移(随 1.0.0 发布)
-- 注意:所有迁移必须幂等(IF NOT EXISTS / ON CONFLICT),回滚后重升不会报错
CREATE TABLE IF NOT EXISTS app_info (
  k text PRIMARY KEY,
  v text
);

INSERT INTO app_info (k, v) VALUES ('installed_at', now()::text)
ON CONFLICT (k) DO NOTHING;
