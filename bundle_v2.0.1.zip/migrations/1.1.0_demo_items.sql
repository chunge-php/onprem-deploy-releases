-- 随 1.1.0 发布的迁移:升级到 1.1.0 时才会执行
CREATE TABLE IF NOT EXISTS demo_items (
  id serial PRIMARY KEY,
  name text NOT NULL,
  created_at timestamptz DEFAULT now()
);

INSERT INTO demo_items (name)
SELECT x FROM (VALUES ('升级到 1.1.0 后新增的数据'), ('看到这行说明迁移已执行')) AS t(x)
WHERE NOT EXISTS (SELECT 1 FROM demo_items);

INSERT INTO app_info (k, v) VALUES ('upgraded_to_1.1.0_at', now()::text)
ON CONFLICT (k) DO UPDATE SET v = EXCLUDED.v;
