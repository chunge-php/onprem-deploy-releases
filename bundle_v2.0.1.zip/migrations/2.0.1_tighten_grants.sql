-- 2.0.1 安全收权:修正 2.0.0 初版过宽的 anon 授权
-- (迁移文件一旦发布不可修改——已执行过的机器会按文件名跳过,所以收权必须用新迁移补)
REVOKE ALL ON schema_migrations FROM anon, authenticated;
REVOKE ALL ON app_info FROM anon, authenticated;
REVOKE ALL ON demo_items FROM anon, authenticated;

-- 撤掉"未来新表自动给 anon 读"的默认权限,只保留 service_role
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE SELECT ON TABLES FROM anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO service_role;

-- 公告表保持公开可读
GRANT SELECT ON announcements TO anon, authenticated, service_role;

NOTIFY pgrst, 'reload schema';
