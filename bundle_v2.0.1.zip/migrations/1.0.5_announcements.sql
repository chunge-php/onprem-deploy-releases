-- 随 1.0.5 发布的迁移:验证「bundle 下载 → sha256 校验 → 升级时执行迁移」全链路
CREATE TABLE IF NOT EXISTS announcements (
  id serial PRIMARY KEY,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

INSERT INTO announcements (content)
SELECT x FROM (VALUES
  ('🎉 这条公告来自 1.0.5 升级时新建的 announcements 表'),
  ('说明 bundle 下载→sha256 校验→数据库迁移 全链路打通')
) AS t(x)
WHERE NOT EXISTS (SELECT 1 FROM announcements);
